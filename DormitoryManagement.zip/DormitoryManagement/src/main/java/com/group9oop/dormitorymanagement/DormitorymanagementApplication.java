package com.group9oop.dormitorymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DormitorymanagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(DormitorymanagementApplication.class, args);
    }
}